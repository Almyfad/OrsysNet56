﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;

namespace ComposantsBlazor.Composants
{
    public partial class DialogueConfirmation
    {
        public bool Visible { get; set; }
        
		
        [Parameter]
        public EventCallback<bool> ReponseCallback { get; set; }
		
        public void Afficher()
        {
            Visible = true;
            StateHasChanged();
        }
		
        public async void Non()
        {
            Visible = false;
            await ReponseCallback.InvokeAsync(false);
            StateHasChanged();
        }

        public async void Oui()
        {
            Visible = false;
            await ReponseCallback.InvokeAsync(true);
            StateHasChanged();
        }
    }
}
