﻿using Microsoft.AspNetCore.Components;

namespace ComposantsBlazor.Composants
{
    public partial class ComposantParametre
    {
        [Parameter]
        public string Message { get; set; } 
    }
}
