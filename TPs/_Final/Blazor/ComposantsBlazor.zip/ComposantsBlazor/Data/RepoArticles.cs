﻿namespace ComposantsBlazor.Data
{
    public class RepoArticles
    {
        public static List<WeatherForecast> Articles { get; set; }
    }
}
