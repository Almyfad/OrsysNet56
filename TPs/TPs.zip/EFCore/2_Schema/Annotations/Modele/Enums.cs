﻿namespace Modele
{
    public enum StatutClient
    {
        Prospect, Actif, Resilie
    }
}
