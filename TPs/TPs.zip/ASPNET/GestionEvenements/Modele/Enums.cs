﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modele
{
    public enum Civilite
    {
        Monsieur = 1, Madame = 2
    }
}
